import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MailboxserviceService {
  // private baseUrl = "http://demo.otpl.in/mbapi"
  //public buttonClick = new Subject();
  private baseUrl = "http://localhost:4876";

  constructor(private http: HttpClient) { }

  getbaseurl() {
    return this.baseUrl;
  }

  AdminLogin(loginData) {
    return this.http.post(this.baseUrl + "/Admin/AdminLogin", loginData);
  }
  UserLastLogin(userId) {
    return this.http.get(this.baseUrl + "/Admin/LastLogin/" + userId);
  }
  UpdateProfile(mobileNo: string, fileToUpload: File, userId) {
    const formData: FormData = new FormData();
    formData.append('ProfilePic', fileToUpload);
    formData.append('mobileNo', mobileNo);
    formData.append('userId', userId);
    return this.http.post(this.baseUrl + "/Admin/UpdateProfile", formData);
  }


  FileHandle(fileToUpload: File) {
    const formData: FormData = new FormData();
    formData.append('ProfilePic', fileToUpload, fileToUpload.name);
    return this.http.post(this.baseUrl + "/File/FileValidation", formData);
  }
  PicHandle(fileToUpload: File) {
    const formData: FormData = new FormData();
    formData.append('ProfilePic', fileToUpload, fileToUpload.name);
    return this.http.post(this.baseUrl + "/File/PicValidation", formData);
  }




  Attachmentsfiles(fileToUpload, Priority, SMS, Subject, Message, Sid, Rid) {
    const formData: FormData = new FormData();
    for (let i = 0; i < fileToUpload.length; i++) {
      formData.append("Attachment[]", fileToUpload[i]);
    }
    for (let i = 0; i < Rid.length; i++) {
      formData.append("Rid", Rid[i].userId);
    }
    formData.append('Priority', Priority);
    formData.append('SMS', SMS);
    formData.append('Subject', Subject);
    formData.append('Message', Message);
    formData.append('Sid', Sid);
    return this.http.post(this.baseUrl + "/User/ComposeMailWithAttachment", formData);
  }


  GroupMaster() {
    return this.http.get(this.baseUrl + "/Admin/GroupMaster");
  }
  AddUpdateGroupMaster(groupMasterData) {
    return this.http.post(this.baseUrl + "/Admin/AddUpdateGroupMaster", groupMasterData);
  }
  DeleteGroupMaster(groupId) {
    console.log(groupId);
    return this.http.get(this.baseUrl + "/Admin/DeleteGroupMaster/" + groupId);
  }
  composemail(mailBox) {
    return this.http.post(this.baseUrl + "/Admin/ComposeMail", mailBox);
  }
  MoveToDraft(Priority, SMS, Subject, Message, Sid) {
    var mailBox = { Priority, SMS, Subject, Message, Sid }
    return this.http.post(this.baseUrl + "/User/Drafts", mailBox);
  }
  allMailFromDraft(Rid) {
    return this.http.get(this.baseUrl + "/User/FromDraft/" + Rid);
  }
  GetGroupUserForManage(groupId) {
    return this.http.get(this.baseUrl + "/Admin/GetGroupUserForManage/" + groupId);
  }
  updateUserMaster(ManageUserData) {
    return this.http.post(this.baseUrl + "/Admin/updateUserMaster", ManageUserData);
  }
  GetLastLogin() {
    return this.http.get(this.baseUrl + "/Admin/GetLastLogin");
  }
  chkgroupName(groupName) {
    return this.http.get(this.baseUrl + "/Admin/CheckGroupName/" + groupName);
  }
  GetsendreceiveStats() {
    return this.http.get(this.baseUrl + "/Admin/SendReceiveStats");
  }
  GetUsedUser() {
    return this.http.get(this.baseUrl + "/Admin/UsedUser");
  }
  GetNotUsedUser() {
    return this.http.get(this.baseUrl + "/Admin/NotUsedUser");
  }
  ActiveDeactiveUser(activeDeactive) {
    return this.http.post(this.baseUrl + "/Admin/ActiveDeactiveUser", activeDeactive);
  }
  GetallOffieName() {
    return this.http.get(this.baseUrl + "/Admin/GetAllOffice");
  }
  ReportByOfficeName(userId) {
    return this.http.get(this.baseUrl + "/Admin/MsgReportByOfficeName/" + userId);
  }
  ReportBysubject(subject) {
    return this.http.get(this.baseUrl + "/Admin/MsgReportBySuject/" + subject);
  }
  ReportBydate(date) {
    return this.http.post(this.baseUrl + "/Admin/MsgReportByDate", date);
  }
  // BroadcastPost(broadCast) {
  //   return this.http.post(this.baseUrl + "/Admin/Broadcast", broadCast);
  // }

  BroadcastPost(Sid, Rid, subject, fileToUpload, Message, sdate) {
    const formData: FormData = new FormData();
    formData.append('BroadcastPic', fileToUpload);
    formData.append('Sid', Sid);
    for (let i = 0; i < Rid.length; i++) {
      formData.append("Rid", Rid[i].userId);
    }
    formData.append('Subject', subject);
    formData.append('Message', Message);
    formData.append('ClosedDate', sdate);


    return this.http.post(this.baseUrl + "/Admin/Broadcast", formData);
  }
  BroadcastGet(rid) {
    return this.http.get(this.baseUrl + "/Admin/BroadcastMessage/" + rid);
  }
  MarkBroadcastSeen(rowid) {
    return this.http.get(this.baseUrl + "/Admin/MarkBroadcastMessageSeen/" + rowid);
  }
  GetBroadcastReport() {
    return this.http.get(this.baseUrl + "/Admin/BroadcastReport");
  }
  GetSendMsgList(message) {
    return this.http.post(this.baseUrl + "/Admin/GetSendMessage", message);
  }
  //****************************************************User Api Call*********************************************************************/
  UserLogin(loginData) {
    return this.http.post(this.baseUrl + "/User/UserLogin", loginData);
  }
  chkNameorMobile(userorMobile) {
    return this.http.post(this.baseUrl + "/Admin/CheckuserOrMobile", userorMobile);
  }
  AddUser(addUser) {
    return this.http.post(this.baseUrl + "/Admin/AddUser", addUser);
  }
  GetUserBygroup(groupId) {
    return this.http.get(this.baseUrl + "/Admin/GetUserBygroup/" + groupId);
  }
  getmail(Rid) {
    return this.http.get(this.baseUrl + "/User/InboxMail/" + Rid);
  }

  // getmail(datat) {
  //   return this.http.post(this.baseUrl + "/User/InboxMail", datat);
  // }


  getmailDetails(mailDes) {
    return this.http.post(this.baseUrl + "/User/MailDetails", mailDes);
  }
  getdraftDetails(mailDes) {
    return this.http.post(this.baseUrl + "/User/DraftDetails", mailDes);
  }
  getattachments(mailDes) {
    return this.http.post(this.baseUrl + "/User/Attachments", mailDes);
  }
  getSentattachments(mailDes) {
    return this.http.post(this.baseUrl + "/User/SentAttachments", mailDes);
  }
  DownloadAttachments(fileName) {
    var downloadFile = { 'fileName': fileName }
    console.log(downloadFile)
    return this.http.post(this.baseUrl + "/User/GetAttachmentFile", downloadFile, { responseType: 'blob' });
  }

  moveToTrash(SelectedIDs) {
    return this.http.get(this.baseUrl + "/User/MoveToTrash/" + SelectedIDs);
  }
  allMailsmoveToTrash(moveToTrash) {
    return this.http.post(this.baseUrl + "/User/AllMailMoveToTrash", moveToTrash);
  }
  allMailFromTrash(Rid) {
    return this.http.get(this.baseUrl + "/User/FromTrash/" + Rid);
  }
  deleteFromTrash(MailId) {
    return this.http.delete(this.baseUrl + "/User/DeleteFromTrash/" + MailId);
  }


  moveToArchive(SelectedIDs) {
    return this.http.get(this.baseUrl + "/User/MoveToArchive/" + SelectedIDs);
  }
  allMailsmoveToArchive(moveToArchive) {
    return this.http.post(this.baseUrl + "/User/AllMailMoveToArchive", moveToArchive);
  }
  allMailFromArchive(Rid) {
    return this.http.get(this.baseUrl + "/User/FromArchive/" + Rid);
  }
  backToInbox(moveToInbox) {
    return this.http.post(this.baseUrl + "/User/MovebackToInbox", moveToInbox);
  }
  moveToImportant(mailId) {
    return this.http.get(this.baseUrl + "/User/MoveToImportant/" + mailId);
  }
  allMailFromImportant(Rid) {
    return this.http.get(this.baseUrl + "/User/AllMailFromImportant/" + Rid);
  }
  forgetPassword(mobileNo) {
    return this.http.get(this.baseUrl + "/User/ForgetPassword/" + mobileNo);
  }
  otpVerification(mobileNo, OTP) {
    var verifyOTP = { 'mobileNo': mobileNo, 'OTP': OTP }
    return this.http.post(this.baseUrl + "/User/VerifyOTP", verifyOTP);
  }
  changePassword(userId, Password) {
    var changePassword = { 'userId': userId, 'Password': Password }
    return this.http.post(this.baseUrl + "/User/ChangePassword", changePassword);
  }
  allMailFromSent(Sid) {
    return this.http.get(this.baseUrl + "/User/SentMails/" + Sid);
  }
  GetSentMailDetails(sendMailDes) {
    return this.http.post(this.baseUrl + "/User/SentMailDes", sendMailDes);
  }
  CheckOldPass(userId, OldPass) {
    var checkOldPass = { 'userId': userId, 'OldPass': OldPass }
    return this.http.post(this.baseUrl + "/User/CheckOldPass", checkOldPass);
  }
  // SendMailReply(reply) {
  //   return this.http.post(this.baseUrl + "/User/MailReply", reply);
  // }
  SendMailReply(fileToUpload, Sid, Rid, Message, MessageId, Priority, Subject) {
    const formData: FormData = new FormData();
    for (let i = 0; i < fileToUpload.length; i++) {
      formData.append("Attachment[]", fileToUpload[i]);
    }
    formData.append('Sid', Sid);
    formData.append('Rid', Rid);
    formData.append('Message', Message);
    formData.append('MessageId', MessageId);
    formData.append('Priority', Priority);
    formData.append('Subject', Subject);

    return this.http.post(this.baseUrl + "/User/MailReply", formData);
  }

  ShowMailReply(sendMailDes) {
    return this.http.post(this.baseUrl + "/User/ShowMailReply", sendMailDes);
  }

  getmailhead(mailDes) {
    return this.http.post(this.baseUrl + "/User/GetMailHead", mailDes);
  }
  updatedraft(msgId) {
    console.log(msgId)
    return this.http.get(this.baseUrl + "/User/UpdateDraft/" + msgId);
  }

  //**************forwrd */
  getforword(forword) {
    return this.http.post(this.baseUrl + "/User/GetForword", forword);
  }
  ForwarMailWithfiles(fileToUpload, Priority, SMS, Subject, Message, Sid, Rid, OldFiles) {
    const formData: FormData = new FormData();
    for (let i = 0; i < fileToUpload.length; i++) {
      formData.append("Attachment[]", fileToUpload[i]);
    }
    for (let i = 0; i < Rid.length; i++) {
      formData.append("Rid", Rid[i].userId);
    }
    for (let i = 0; i < OldFiles.length; i++) {
      formData.append("OldFiles", OldFiles[i]);
    }
    formData.append('Priority', Priority);
    formData.append('SMS', SMS);
    formData.append('Subject', Subject);
    formData.append('Message', Message);
    formData.append('Sid', Sid);
    return this.http.post(this.baseUrl + "/User/Forwarmail", formData);
  }
}
