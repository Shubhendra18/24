
import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { MailboxserviceService } from '../mailboxservice.service';
import * as CryptoJS from 'crypto-js';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-user-archive',
  templateUrl: './user-archive.component.html',
  styles: []
})
export class UserArchiveComponent implements OnInit {
  SData: any;
  p: number = 1;

  allmails: any = [];
  SelectedIDs: any = [];
  allmailtotrash: boolean = false;
  decrypt = localStorage.getItem("userToken").toString();
  Rid = CryptoJS.AES.decrypt(this.decrypt.trim(), "ut").toString(CryptoJS.enc.Utf8);
  baseurl: any = "";
  selectAll: any;
  constructor(private service: MailboxserviceService, private toastr: ToastrService) {
    this.baseurl = this.service.getbaseurl();
  }
  getShortName(fullName) {
    if (fullName != null) {
      return fullName.split(' ').map(n => n[0]).join('');
    }
  }
  ngOnInit() {
    this.service.allMailFromArchive(this.Rid).subscribe(k => {
      this.allmails = k;
    });
  }
  BackToInbox(mailId) {
    var moveToInbox = { "mailId": mailId, "flag": 0 };
    this.service.backToInbox(moveToInbox).subscribe(k => {
      if (k == "success") {
        this.toastr.success('moved To Inbox!', 'Success');
        this.ngOnInit();
      }
      else {
        this.toastr.error('Failed to Moved To Inbox!', 'Error');
      }
    });
  }

  checkAll() {
    for (let index = 0; index < this.allmails.length; index++) {
      this.allmails[index].state = this.selectAll
    }
    this.FieldsChange();
  }
  isAllChecked() {
    this.selectAll = this.allmails.every(function (item: any) {
      return item.state == true;
    })
    this.FieldsChange();
  }
  FieldsChange() {
    this.SelectedIDs = [];
    for (let index = 0; index < this.allmails.length; index++) {
      if (this.allmails[index].state)
        this.SelectedIDs.push(this.allmails[index].mailId);
    }
    this.SelectedIDs = JSON.stringify(this.SelectedIDs);
  }
  deleteSelected() {
    if (this.selectAll == true && this.allmails.length > 0) {
      Swal.fire({
        title: 'Are You Sure To Move all Mails?',
        icon: 'warning',
        confirmButtonColor: '#3085d6',
        confirmButtonText: 'Move Data',
        showCloseButton: true,
        showCancelButton: true,
      }).then((result) => {
        if (result.value) {
          this.service.moveToTrash(this.SelectedIDs).subscribe(k => {
            if (k == "Success") {
              this.toastr.info('Moved To Trash!', 'Success');
              this.ngOnInit();
              this.selectAll = "";
              this.SelectedIDs = [];
              this.SelectedIDs = "";
            }
            else {
              this.toastr.error('Failed to Moved To Trash!', 'Error');
            }
          });
        }
      })
    }
    else {
      if (this.selectAll == false && this.SelectedIDs != []) {
        this.service.moveToTrash(this.SelectedIDs).subscribe(k => {
          if (k == "Success") {
            this.toastr.info('Moved To Trash!', 'Success');
            this.ngOnInit();
            this.selectAll = "";
            this.SelectedIDs = [];
            this.SelectedIDs = "";
          }
          else {
            this.toastr.error('Failed to Moved To Trash!', 'Error');
          }
        });
      }
    }
  }
}
