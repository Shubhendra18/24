import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import Swal from 'sweetalert2';
import { MailboxserviceService } from '../mailboxservice.service';
import { CookieService } from 'ngx-cookie-service';
import * as CryptoJS from 'crypto-js';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {
  officeName: any;
  PasswordData: any;
  CaptchaData: any;

  defaultgroup = null;
  defaultname = null;
  groupData: any = [];
  users: any = [];
  captchaKey: string = "";
  captchaerror = false;
  encrpt: string;
  plainText: string;
  baseurl: any = "";
  captchapic: any;
  public loading = false;
  constructor(private service: MailboxserviceService, private toaster: ToastrService, private router: Router, private cookieService: CookieService) {
    this.baseurl = this.service.getbaseurl();
    this.captchapic = this.baseurl + "/Admin/GetCaptcha";

  }

  ngOnInit() {
    this.service.GroupMaster().subscribe(k => {
      this.groupData = k;
    });

  }
  onSelect(value) {
    this.service.GetUserBygroup(value).subscribe(k => {
      this.users = k;
    });
  }
  refreshcaptcha() {
    this.captchapic = this.baseurl + "/Admin/GetCaptcha?=" + Math.random();
  }

  login(loginData) {
    this.loading = true;
    this.service.UserLogin(loginData.value).subscribe((data: any) => {
      this.plainText = data.userId.toString();
      this.encrpt = CryptoJS.AES.encrypt(this.plainText, "ut").toString();
      localStorage.setItem('userToken', this.encrpt);
      this.loading = false;
      this.router.navigate(['/inbox']);
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        Swal.fire({
          icon: 'warning',
          title: err.error.message,
          text: "Warning",
        })
        this.loading = false;
        this.refreshcaptcha();
        this.CaptchaData = "";
        this.PasswordData = "";
      };
    });
  }
  reset() {
    this.defaultgroup = null;
    this.defaultname = null;
    this.users = [];
  }
}
