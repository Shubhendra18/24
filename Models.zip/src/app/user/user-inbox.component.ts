import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { MailboxserviceService } from '../mailboxservice.service';
import { HttpErrorResponse } from '@angular/common/http';
import * as CryptoJS from 'crypto-js';
import { empty } from 'rxjs';
import Swal from 'sweetalert2';

declare var $;

@Component({
  selector: 'app-user-inbox',
  templateUrl: './user-inbox.component.html',
  styles: []
})
export class UserInboxComponent implements OnInit {

  allmails: any = [];
  SData: any;
  SelectedIDs: any = [];
  i: number = 0;
  decrypt = localStorage.getItem("userToken").toString();
  Rid = CryptoJS.AES.decrypt(this.decrypt.trim(), "ut").toString(CryptoJS.enc.Utf8);

  isimportant = "text-dark";
  p: any;

  profilepic = "";
  baseurl: any = "";
  selectAll: any;

  /***** */

  totalRec: number;
  page: number = 1;
  broadcastmsg: any = [];
  configtwo: any;

  //**** */
  constructor(private service: MailboxserviceService, private toastr: ToastrService) {
    this.baseurl = this.service.getbaseurl();
  }
  getShortName(fullName) {
    if (fullName != null) {
      return fullName.split(' ').map(n => n[0]).join('');
    }
  }
  ngOnInit() {
    // var datat = { 'PageNumber': 1, 'ItemsPerPage': 50, 'Rid': this.Rid };
    // this.service.getmail(datat).subscribe(k => {
    //   this.allmails = k['data'];
    //   this.total = k['Total'];

    // });
    this.configtwo = {
      id: 'second',
      itemsPerPage: 4,
      currentPage: 1
    };
    this.service.getmail(this.Rid).subscribe(k => {
      this.allmails = k;
    });
    this.bradcast();

  }
  bradcast() {
    this.service.BroadcastGet(this.Rid).subscribe(k => {
      if (k != null) {
        this.broadcastmsg = k;
        if (this.broadcastmsg.filter(k => k.isSeen == false).length > 0 && localStorage.getItem("seen") === null) {
          Swal.fire({
            title: this.broadcastmsg.filter(k => k.isSeen == false).length + ' New Broadcast Message Received',
            icon: 'info',
            html: '<b> Click On Bell icon To See The Broadcast</b>',
            showCloseButton: true,
            focusConfirm: true,
            confirmButtonText:
              '<i class="fa fa-check"></i> OK, View Now',
            confirmButtonAriaLabel: 'View',
            showClass: {
              popup: 'animated fadeInDown faster'
            },
            hideClass: {
              popup: 'animated fadeOutUp faster'
            }
          }).then((result) => {
            if (result.value) {
              localStorage.setItem("seen", "yes");
            }
          })
        }

      }
      else {
        $("#modelId").modal('hide');
      }
    });
  }
  get totalrmsg(): number {
    return this.allmails.filter(i => i.isViewed).length;
  }

  get totalumsg(): number {
    return this.allmails.filter(i => !i.isViewed).length;
  }
  //******* */
  checkAll() {

    for (let index = 0; index < this.allmails.length; index++) {
      this.allmails[index].state = this.selectAll
    }
    this.FieldsChange();
  }
  isAllChecked() {
    this.selectAll = this.allmails.every(function (item: any) {
      return item.state == true;
    })
    this.FieldsChange();
  }
  FieldsChange() {
    this.SelectedIDs = [];
    for (let index = 0; index < this.allmails.length; index++) {
      if (this.allmails[index].state)
        this.SelectedIDs.push(this.allmails[index].mailId);
    }
    this.SelectedIDs = JSON.stringify(this.SelectedIDs);
  }

  //******* */
  deleteSelected() {
    if (this.selectAll == true && this.allmails.length > 0) {
      Swal.fire({
        title: 'Are You Sure To Move all Mails?',
        icon: 'warning',
        confirmButtonColor: '#3085d6',
        confirmButtonText: 'Move Data',
        showCloseButton: true,
        showCancelButton: true,
      }).then((result) => {
        if (result.value) {
          this.service.moveToTrash(this.SelectedIDs).subscribe(k => {
            if (k == "Success") {
              this.toastr.info('Moved To Trash!', 'Success');
              this.ngOnInit();
              this.selectAll = "";
              this.SelectedIDs = [];
              this.SelectedIDs = "";
            }
            else {
              this.toastr.error('Failed to Moved To Trash!', 'Error');
            }
          });
        }
      })
    }
    else {
      if (this.selectAll == false && this.SelectedIDs != []) {
        this.service.moveToTrash(this.SelectedIDs).subscribe(k => {
          if (k == "Success") {
            this.toastr.info('Moved To Trash!', 'Success');
            this.ngOnInit();
            this.selectAll = "";
            this.SelectedIDs = [];
            this.SelectedIDs = "";
          }
          else {
            this.toastr.error('Failed to Moved To Trash!', 'Error');
          }

        });
      }
    }
  }
  archivedSelected() {
    if (this.selectAll == true && this.allmails.length > 0) {
      Swal.fire({
        title: 'Are You Sure To Move all Mails?',
        icon: 'warning',
        confirmButtonColor: '#3085d6',
        confirmButtonText: 'Move Data',
        showCloseButton: true,
        showCancelButton: true,
      }).then((result) => {
        if (result.value) {
          this.service.moveToArchive(this.SelectedIDs).subscribe(k => {
            if (k == "Success") {
              this.toastr.info('Moved To Archived!', 'Success');
              this.ngOnInit();
              this.selectAll = "";
              this.SelectedIDs = [];
              this.SelectedIDs = "";
            }
            else {
              this.toastr.error('Failed to Moved To Archived!', 'Error');
            }
          });
        }
      })
    }
    else {
      if (this.selectAll == false && this.SelectedIDs != []) {
        this.service.moveToArchive(this.SelectedIDs).subscribe(k => {
          if (k == "Success") {
            this.toastr.info('Moved To Archived!', 'Success');
            this.ngOnInit();
            this.selectAll = "";
            this.SelectedIDs = [];
            this.SelectedIDs = "";
          }
          else {
            this.toastr.error('Failed to Moved To Archived!', 'Error');
          }

        });
      }
    }
  }

  Refresh() {
    this.ngOnInit();
    this.selectAll = "";
    this.SelectedIDs = [];
    this.SelectedIDs = "";


  }
  markasImportant(mailId) {
    this.service.moveToImportant(mailId).subscribe(k => {
      if (k == "success") {
        this.toastr.success('Moved To Important!', 'Success');
        this.ngOnInit();
      }
      else {
        this.toastr.error('Failed to Moved To Archived!', 'Error');
      }
    });
  }
  trackByFn(index: number, item) {
    return index;
  }
  pageChangedtwo(event) {
    this.configtwo.currentPage = event;
  }
}
