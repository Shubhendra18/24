import { Component, OnInit, QueryList, ViewChildren } from '@angular/core';
import { Subject } from 'rxjs';
import { DataTableDirective } from 'angular-datatables';
import { MailboxserviceService } from '../mailboxservice.service';
import { Variable } from '@angular/compiler/src/render3/r3_ast';
declare var $;
@Component({
  selector: 'app-usernotusingmboard',
  templateUrl: './usernotusingmboard.component.html',
  styles: []
})
export class UsernotusingmboardComponent implements OnInit {
  usedUserData: any = [];
  notusedUserData: any = [];
  @ViewChildren(DataTableDirective)
  dtElements: QueryList<any>;
  dtOptions: any = [];
  dtTrigger = new Subject();
  rptdate = new Date();
  constructor(private service: MailboxserviceService) { }
  // displayToConsole(): void {
  //   this.dtElements.forEach((dtElement: DataTableDirective, index: number) => {
  //     dtElement.dtInstance.then((dtInstance: any) => {
  //       console.log(`The DataTable ${index} instance ID is: ${dtInstance.table().node().id}`);
  //     });
  //   });
  // }
  ngOnInit() {
    this.service.GetUsedUser().subscribe(k => {
      this.usedUserData = k;
      this.dtTrigger.next();
    });
    this.service.GetNotUsedUser().subscribe(k => {
      this.notusedUserData = k;
    });

    this.dtOptions[0] = {
      pageLength: 10, pagingType: 'full_numbers', dom: 'lfrtip', paging: true
    };
    this.dtOptions[1] = {
      pageLength: 10, pagingType: 'full_numbers', dom: 'lfrtip', paging: true
    };
  }
  trackByName(index: number, k: any): string {
    return k.groupName
  }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
  PrintDoc() {
    var toPrint = document.getElementById('demo-tabs-box-1');
    var popupWin = window.open('', '_blank', 'left=100,top=100,width=1100,height=600,tollbar=0,scrollbars=1,status=0,resizable=1');
    popupWin.document.open();
    popupWin.document.write('<html><title></title> <style>body{font-family:Arial}.dataTables_wrapper{padding-bottom: 30px;}.tblhed{display:table !important;} .tblhed td{border:0 !important} table{border-collapse: collapse; width:100%;} table td, table th{border:1px solid #000; padding:3px 5px; font-size:10pt;} .mt-2 th{text-align:left !important;} .dataTables_filter, .dataTables_info, .dataTables_paginate, .dataTables_length,.btn{display: none;}</style></head><body onload="window.print()"> ')
    popupWin.document.write(toPrint.innerHTML);
    popupWin.document.write('<div style="width:100%; text-align:center; font-size:9pt; position: fixed; bottom: 20px;">** This is a Software Generated Report ** </div></body></html>');
    popupWin.document.close();
  }
  PrintDocsec() {
    var toPrint = document.getElementById('demo-tabs-box-2');
    var popupWin = window.open('', '_blank', 'left=100,top=100,width=1100,height=600,tollbar=0,scrollbars=1,status=0,resizable=1');
    popupWin.document.open();
    popupWin.document.write('<html><title></title> <style>body{font-family:Arial}.dataTables_wrapper{padding-bottom: 30px;}.tblhed{display:table !important;} .tblhed td{border:0 !important} table{border-collapse: collapse; width:100%;} table td, table th{border:1px solid #000; padding:3px 5px; font-size:10pt;} .mt-2 th{text-align:left !important;} .dataTables_filter, .dataTables_info, .dataTables_paginate, .dataTables_length,.btn{display: none;}</style></head><body onload="window.print()"> ')
    popupWin.document.write(toPrint.innerHTML);
    popupWin.document.write('<div style="width:100%; text-align:center; font-size:9pt; position: fixed; bottom: 20px;">** This is a Software Generated Report ** </div></body></html>');
    popupWin.document.close();
  }
}
