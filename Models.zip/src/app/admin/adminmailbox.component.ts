import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { MailboxserviceService } from '../mailboxservice.service';
import * as CryptoJS from 'crypto-js';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-adminmailbox',
  templateUrl: './adminmailbox.component.html',
  styles: []
})
export class AdminmailboxComponent implements OnInit {
  SData: any;

  allmails: any = [];
  SelectedIDs: any = [];
  i: number = 0;
  allmailtotrash: boolean = false;
  decryptnew = localStorage.getItem("Token").toString();
  Rid = CryptoJS.AES.decrypt(this.decryptnew.trim(), "at").toString(CryptoJS.enc.Utf8);
  isimportant = "text-dark";
  isSelected: boolean = false;
  names: any;
  selectAll: any;
  baseurl: any = "";

  p: number = 1;
  total: number = 0;
  itemPerPage: number = 3;
  pageChanged($event): void {
    this.p = $event;
    this.ngOnInit();

  }
  totalRec: number;
  page: number = 1;


  constructor(private service: MailboxserviceService, private toastr: ToastrService) {
    this.baseurl = this.service.getbaseurl();

  }
  get totalrmsg(): number {
    return this.allmails.filter(i => i.isViewed).length;
  }

  get totalumsg(): number {
    return this.allmails.filter(i => !i.isViewed).length;
  }
  getShortName(fullName) {
    if (fullName != null) {
      return fullName.split(' ').map(n => n[0]).join('');
    }
  }
  ngOnInit() {
    this.service.getmail(this.Rid).subscribe(k => {
      this.allmails = k;
    });
  }
  checkAll() {
    for (let index = 0; index < this.allmails.length; index++) {
      this.allmails[index].state = this.selectAll
    }
    this.FieldsChange();
  }
  isAllChecked() {
    this.selectAll = this.allmails.every(function (item: any) {
      return item.state == true;
    })
    this.FieldsChange();
  }
  FieldsChange() {
    this.SelectedIDs = [];
    for (let index = 0; index < this.allmails.length; index++) {
      if (this.allmails[index].state)
        this.SelectedIDs.push(this.allmails[index].mailId);
    }
    this.SelectedIDs = JSON.stringify(this.SelectedIDs);
  }
  deleteSelected() {
    if (this.selectAll == true && this.allmails.length > 0) {
      Swal.fire({
        title: 'Are You Sure To Move all Mails?',
        icon: 'warning',
        confirmButtonColor: '#3085d6',
        confirmButtonText: 'Move Data',
        showCloseButton: true,
        showCancelButton: true,
      }).then((result) => {
        if (result.value) {
          this.service.moveToTrash(this.SelectedIDs).subscribe(k => {
            if (k == "Success") {
              this.toastr.info('Moved To Trash!', 'Success');
              this.ngOnInit();
              this.selectAll = "";
              this.SelectedIDs = [];
              this.SelectedIDs = "";
            }
            else {
              this.toastr.error('Failed to Moved To Trash!', 'Error');
            }
          });
        }
      })
    }
    else {
      if (this.selectAll == false && this.SelectedIDs != []) {
        this.service.moveToTrash(this.SelectedIDs).subscribe(k => {
          if (k == "Success") {
            this.toastr.info('Moved To Trash!', 'Success');
            this.ngOnInit();
            this.selectAll = "";
            this.SelectedIDs = [];
            this.SelectedIDs = "";
          }
          else {
            this.toastr.error('Failed to Moved To Trash!', 'Error');
          }
        });
      }
    }
  }
  archivedSelected() {
    if (this.selectAll == true && this.allmails.length > 0) {
      Swal.fire({
        title: 'Are You Sure To Move all Mails?',
        icon: 'warning',
        confirmButtonColor: '#3085d6',
        confirmButtonText: 'Move Data',
        showCloseButton: true,
        showCancelButton: true,
      }).then((result) => {
        if (result.value) {
          this.service.moveToArchive(this.SelectedIDs).subscribe(k => {
            if (k == "Success") {
              this.toastr.info('Moved To Archived!', 'Success');
              this.ngOnInit();
              this.selectAll = "";
              this.SelectedIDs = [];
              this.SelectedIDs = "";
            }
            else {
              this.toastr.error('Failed to Moved To Archived!', 'Error');
            }
          });
        }
      })
    }
    else {
      if (this.selectAll == false && this.SelectedIDs != []) {
        this.service.moveToArchive(this.SelectedIDs).subscribe(k => {
          if (k == "Success") {
            this.toastr.info('Moved To Archived!', 'Success');
            this.ngOnInit();
            this.selectAll = "";
            this.SelectedIDs = [];
            this.SelectedIDs = "";
          }
          else {
            this.toastr.error('Failed to Moved To Archived!', 'Error');
          }
        });
      }
    }
  }
  Refresh() {
    this.ngOnInit();
    this.selectAll = "";
    this.SelectedIDs = [];
    this.SelectedIDs = "";

  }
  markasImportant(mailId) {
    this.service.moveToImportant(mailId).subscribe(k => {
      if (k == "success") {
        this.toastr.success('Moved To Important!', 'Success');
        this.ngOnInit();
      }
      else {
        this.toastr.error('Failed to Moved To Archived!', 'Error');
      }
    });
  }
  trackByFn(index: number, item) {
    return index;
  }
}
