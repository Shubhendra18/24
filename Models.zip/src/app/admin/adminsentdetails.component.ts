import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MailboxserviceService } from '../mailboxservice.service';
import * as CryptoJS from 'crypto-js';
import { saveAs } from 'file-saver';

@Component({
  selector: 'app-adminsentdetails',
  templateUrl: './adminsentdetails.component.html',
  styles: []
})
export class AdminsentdetailsComponent implements OnInit {
  decryptnew = localStorage.getItem("Token").toString();
  Rid = CryptoJS.AES.decrypt(this.decryptnew.trim(), "at").toString(CryptoJS.enc.Utf8);
   maildetails: any = {};
  attachments: any = [];
  attachmentcount: number = 0;
  constructor(private service: MailboxserviceService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      var sendMailDes = { "userId": this.Rid, "messageid": params.get('amessageid') };
      this.service.GetSentMailDetails(sendMailDes).subscribe(k => {
        this.maildetails = k;
      })
      var mailDes = { "mailId": params.get('amessageid'), "rid": this.Rid };
      this.service.getSentattachments(mailDes).subscribe(k => {
        this.attachments = k;
        this.attachmentcount = this.attachments.length;
      })
    });
  }
  getShortName(fullName) {
    if (fullName != null) {
      return fullName.split(' ').map(n => n[0]).join('');
    }
  }
  Download(attachment) {
    this.service.DownloadAttachments(attachment).subscribe(k => {
      saveAs(k, attachment);
    });
  }
}
