import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { MailboxserviceService } from '../mailboxservice.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-manage-user',
  templateUrl: './manage-user.component.html',
  styles: []
})
export class ManageUserComponent implements OnInit {
  groupData: any = [];
  defaultgroup = null;
  values = '';
  alreadytaken: boolean = false;
  mobilealreadytaken: boolean = false;
  public loading = false;

  constructor(private service: MailboxserviceService, private toaster: ToastrService) { }

  ngOnInit() {
    this.service.GroupMaster().subscribe(k => {
      this.groupData = k;
    });
  }
  onChange(event: any) {
    this.values = event.target.value;
    var userorMobile = { 'userorMobile': this.values, 'flag': '0' };
    this.service.chkNameorMobile(userorMobile).subscribe((data: any) => {
      if (data === "Success") {
        this.alreadytaken = false;
      }
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        this.alreadytaken = true;
      };
    });
  }
  onMobileChange(event: any) {
    this.values = event.target.value;
    var userorMobile = { 'userorMobile': this.values, 'flag': '1' };
    this.service.chkNameorMobile(userorMobile).subscribe((data: any) => {
      if (data === "Success") {
        this.mobilealreadytaken = false;
      }
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        this.mobilealreadytaken = true;
      };
    });
  }
  addNewUser(addUser) {
    this.loading = true;
    if (this.alreadytaken == false) {
      this.service.AddUser(addUser.value).subscribe((data: any) => {
        if (data == "success") {
          this.loading = false;
          Swal.fire({
            icon: 'success',
            title: 'Success!',
            text: "User Created & Login Details are sent to user's Registered Mobile Number",
          })
        }
        else {
          this.toaster.error('Something went wrong', 'Error');
        }
      }, (err: HttpErrorResponse) => {
        if (err.status === 400) {
          this.loading = false;
          this.toaster.error(err.error.message, 'Error');
        };
      });
    }
    else {
      this.loading = false;
      Swal.fire({
        icon: 'warning',
        title: 'Please try Another user Name!',
        text: "Warning",
      }).then((result) => {
        if (result.value) {
          this.loading = false;
        }
      })
    }
  }
  reset() {
    this.alreadytaken = false;
    this.mobilealreadytaken = false;
  }
}
