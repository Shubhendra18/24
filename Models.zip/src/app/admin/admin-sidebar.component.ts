import { Component, OnInit } from '@angular/core';
import { MailboxserviceService } from '../mailboxservice.service';
import { Router } from '@angular/router';
import * as CryptoJS from 'crypto-js';


@Component({
  selector: 'app-admin-sidebar',
  templateUrl: './admin-sidebar.component.html',
  styles: []
})
export class AdminSidebarComponent implements OnInit {
  totalinbox: number = 0;
  totasend: number = 0;
  totaimportant: number = 0;
  totadarft: number = 0;
  totalarchive: number = 0;
  totaltrash: number = 0;


  listinbox: any = [];
  listsend: any = [];
  listimportant: any = [];
  listdarft: any = [];
  listarchive: any = [];
  listtrash: any = [];
  decryptnew = localStorage.getItem("Token").toString();
  Rid = CryptoJS.AES.decrypt(this.decryptnew.trim(), "at").toString(CryptoJS.enc.Utf8);
  constructor(private service: MailboxserviceService, private router: Router) { }

  ngOnInit() {
    this.service.getmail(this.Rid).subscribe(k => {
      this.listinbox = k;
      this.totalinbox = this.listinbox.length;
    });

    this.service.allMailFromTrash(this.Rid).subscribe(k => {
      this.listtrash = k;
      this.totaltrash = this.listtrash.length;
    });

    this.service.allMailFromArchive(this.Rid).subscribe(k => {
      this.listarchive = k;
      this.totalarchive = this.listarchive.length;
    });

    this.service.allMailFromImportant(this.Rid).subscribe(k => {
      this.listimportant = k;
      this.totaimportant = this.listimportant.length;

    });

    this.service.allMailFromDraft(this.Rid).subscribe(k => {
      this.listdarft = k;
      this.totadarft = this.listdarft.length;
    });
    this.service.allMailFromSent(this.Rid).subscribe(k => {
      this.listsend = k;
      this.totasend = this.listsend.length;
    });
  }
  Logout() {
    localStorage.removeItem('Token');
    this.router.navigate(['/admin']);
  }
}
