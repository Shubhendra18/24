import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
declare let $: any;

@Component({
  selector: 'app-admin-navbar',
  templateUrl: './admin-navbar.component.html',
  styles: []
})
export class AdminNavbarComponent implements OnInit, AfterViewInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
  ngAfterViewInit() {
    $.getScript('assets/js/mycutometoggle.js');
    //$.getScript('assets/js/nifty.min.js');
  }
  Logout() {
    localStorage.removeItem('Token');
    this.router.navigate(['/admin']);
  }

}
